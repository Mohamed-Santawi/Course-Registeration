-- Database Migration Script for Course Registration System
-- This script adds unique constraints and updates the profile_image column

-- Step 1: Clean up duplicate emails (keep the user with the lowest ID)
DELETE FROM user_profiles
WHERE user_id IN (
    SELECT id FROM users
    WHERE email IN (
        SELECT email FROM users
        GROUP BY email
        HAVING COUNT(*) > 1
    )
    AND id NOT IN (
        SELECT MIN(id) FROM users
        GROUP BY email
    )
);

DELETE FROM users
WHERE email IN (
    SELECT email FROM users
    GROUP BY email
    HAVING COUNT(*) > 1
)
AND id NOT IN (
    SELECT MIN(id) FROM users
    GROUP BY email
);

-- Step 2: Clean up duplicate student IDs (keep the user with the lowest ID)
DELETE FROM user_profiles
WHERE user_id IN (
    SELECT user_id FROM user_profiles
    WHERE student_id IN (
        SELECT student_id FROM user_profiles
        WHERE student_id IS NOT NULL
        GROUP BY student_id
        HAVING COUNT(*) > 1
    )
    AND user_id NOT IN (
        SELECT MIN(user_id) FROM user_profiles
        WHERE student_id IS NOT NULL
        GROUP BY student_id
    )
);

-- Step 3: Add unique constraint to users.email
ALTER TABLE users
ADD CONSTRAINT unique_email UNIQUE (email);

-- Step 4: Update user_profiles table structure
-- First, drop the existing profile_image column if it exists
ALTER TABLE user_profiles
DROP COLUMN IF EXISTS profile_image;

-- Add the new profile_image column as LONGBLOB
ALTER TABLE user_profiles
ADD COLUMN profile_image LONGBLOB;

-- Add image_content_type column
ALTER TABLE user_profiles
ADD COLUMN image_content_type VARCHAR(255);

-- Add unique constraint to student_id
ALTER TABLE user_profiles
ADD CONSTRAINT unique_student_id UNIQUE (student_id);

-- Step 5: Update foreign key constraint to use CASCADE DELETE
-- Drop existing foreign key constraint
ALTER TABLE user_profiles
DROP FOREIGN KEY IF EXISTS FKjcad5nfve11khsnpwj1mv8frj;

-- Add foreign key constraint with CASCADE DELETE
ALTER TABLE user_profiles
ADD CONSTRAINT FKjcad5nfve11khsnpwj1mv8frj
FOREIGN KEY (user_id) REFERENCES users(id)
ON DELETE CASCADE;

-- Step 6: Verify the changes
SELECT 'Migration completed successfully!' as status;

-- Step X: Add year and type columns to courses
ALTER TABLE courses ADD COLUMN year VARCHAR(10);
ALTER TABLE courses ADD COLUMN type VARCHAR(20);

-- Step X: Create join table for many-to-many relationship between courses and programs
CREATE TABLE IF NOT EXISTS course_programs (
    course_id BIGINT NOT NULL,
    program_id BIGINT NOT NULL,
    PRIMARY KEY (course_id, program_id),
    CONSTRAINT fk_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    CONSTRAINT fk_program FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE CASCADE
);

-- Step X: (Optional) If you want to drop old program_courses table if it exists
DROP TABLE IF EXISTS program_courses;