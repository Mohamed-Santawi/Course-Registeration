-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 16, 2025 at 03:50 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ex4`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `id` bigint(20) NOT NULL,
  `capacity` int(11) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `instructor` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `year` varchar(255) DEFAULT NULL,
  `semester` varchar(255) NOT NULL,
  `code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`id`, `capacity`, `description`, `instructor`, `title`, `type`, `year`, `semester`, `code`) VALUES
(1, 100, 'This course introduces students to the fundamentals of programming using a modern language such as Python or Java. Topics include variables, data types, control structures, functions, arrays/lists, and basic debugging techniques. The course emphasizes pro', NULL, 'Introduction to Programming', NULL, '1st Year', 'A', 'CS101'),
(2, 100, 'This course covers essential data structures (arrays, stacks, queues, linked lists, trees, graphs) and algorithms (sorting, searching, recursion, dynamic programming). Students will analyze algorithm complexity and performance using Big O notation and imp', NULL, 'Data Structures and Algorithms', NULL, '1st Year', 'A', 'CS102'),
(3, 100, 'Explore the internal workings of modern computers, from binary logic to CPU design. Topics include number systems, digital circuits, instruction cycles, memory hierarchy, and input/output systems. This course helps bridge hardware and software understandi', NULL, 'Computer Architecture and Organization', NULL, '1st Year', 'A', 'CS103'),
(4, 100, 'This course introduces the concepts of object-oriented programming including classes, objects, inheritance, polymorphism, encapsulation, and abstraction using a language such as Java or C++. Students will develop modular and reusable applications.', NULL, 'Object-Oriented Programming (OOP)', NULL, '1st Year', 'A', 'CS203'),
(5, 100, 'This course dives into the design and implementation of modern operating systems. Topics include process management, memory allocation, file systems, device management, synchronization, and security. Students will understand how OS components interact wit', NULL, 'Operating Systems', NULL, '1st Year', 'B', 'CS201'),
(6, 100, 'Students will learn about relational database systems, SQL queries, normalization, indexing, transactions, and ER modeling. The course includes practical labs using MySQL or PostgreSQL to build and manage databases.', NULL, 'Database Systems', NULL, '1st Year', 'B', 'CS202'),
(7, 100, 'This course introduces full-stack web development using HTML, CSS, JavaScript, and a backend language (like PHP or Node.js). Topics include REST APIs, responsive design, user authentication, and deployment.', NULL, 'Web Development', NULL, '1st Year', 'B', 'CS301'),
(8, 100, 'Covers the software development life cycle, design patterns, version control (Git), testing, and agile methodologies. Students will work in teams to plan, design, develop, and document a software project.', NULL, 'Software Engineering', NULL, '1st Year', 'B', 'CS302'),
(9, 100, 'Covers the fundamentals of developing applications for mobile platforms (Android or iOS). Topics include UI design, navigation, data persistence, APIs, sensors, and publishing to app stores.', NULL, 'Mobile App Development', NULL, '1st Year', 'C', 'CS303'),
(10, 100, 'This course provides an introduction to computer security, covering topics such as encryption, authentication, firewalls, malware, ethical hacking, and best practices for securing networks and applications.', NULL, 'Cybersecurity Fundamentals', NULL, '1st Year', 'C', 'CS304'),
(11, 100, 'Introduces the study and design of user interfaces with a focus on usability, accessibility, user research, and interaction techniques. Students will prototype interfaces and conduct user testing.', NULL, 'Human-Computer Interaction (HCI)', NULL, '1st Year', 'C', 'CS305'),
(12, 100, 'Focuses on the techniques used to create and manipulate graphics using code. Topics include rendering, 2D/3D transformations, modeling, shaders, and OpenGL/WebGL programming.', NULL, 'Computer Graphics', NULL, '1st Year', 'C', 'CS306'),
(13, 100, 'This course explores network architectures, protocols (TCP/IP, HTTP, FTP), addressing, routing, and network security. Labs may include setting up virtual networks and capturing packets with tools like Wireshark.', NULL, 'Computer Networks', NULL, '2nd Year', 'A', 'CS401'),
(14, 100, 'An introduction to AI concepts including search algorithms, machine learning, neural networks, natural language processing, and robotics. Students will implement simple intelligent systems and learn ethical considerations in AI.', NULL, 'Artificial Intelligence (AI)', NULL, '2nd Year', 'A', 'CS402'),
(15, 100, 'Explore cloud computing concepts including virtualization, cloud services (IaaS, PaaS, SaaS), deployment models, and cloud platforms like AWS or Azure. The course includes hands-on experience with cloud-based hosting and storage.', NULL, 'Cloud Computing', NULL, '2nd Year', 'A', 'CS403'),
(16, 100, 'An in-depth introduction to supervised, unsupervised, and reinforcement learning. Students will use Python libraries such as Scikit-learn, Pandas, and TensorFlow to build predictive models from real datasets.', NULL, 'Machine Learning', NULL, '2nd Year', 'A', 'CS404'),
(17, 100, 'This practical course teaches how to ethically test and secure systems against hackers. Topics include vulnerability scanning, network penetration, password cracking, and legal considerations of ethical hacking.', NULL, 'Ethical Hacking and Penetration Testing', NULL, '2nd Year', 'B', 'CS405'),
(18, 100, 'Covers the principles and tools of DevOps, including CI/CD pipelines, version control, Docker, Kubernetes, Jenkins, and automated testing. Students will build modern deployment workflows.', NULL, 'DevOps and Continuous Integration', NULL, '2nd Year', 'B', 'CS406'),
(101, 100, 'This foundational course introduces the principles of electric circuits, including Ohm\'s Law, Kirchhoff\'s Laws, Thevenin and Norton theorems, and nodal/mesh analysis. Students learn to analyze and design basic DC and AC circuits using resistors, capacitor', NULL, 'Circuit Analysis', NULL, '1st Year', 'A', 'EE101'),
(102, 100, 'Covers the theory and applications of electric and magnetic fields. Topics include Coulomb\'s Law, Gauss\'s Law, Ampère’s Law, and Maxwell’s equations. Practical applications include wave propagation, antennas, and transmission lines.', NULL, 'Electromagnetics', NULL, '1st Year', 'A', 'EE102'),
(103, 100, 'Focuses on the design of digital systems using logic gates, flip-flops, multiplexers, decoders, and programmable logic devices. Students design and simulate combinational and sequential circuits.', NULL, 'Digital Logic Design', NULL, '1st Year', 'B', 'EE201'),
(104, 100, 'Explores semiconductor devices such as diodes, BJTs, and MOSFETs. Topics include amplifiers, biasing, feedback, and frequency response. Labs reinforce real-world circuit behavior and measurements.', NULL, 'Analog Electronics', NULL, '1st Year', 'B', 'EE202'),
(105, 100, 'Introduces signal representation in time and frequency domains. Covers convolution, Fourier transforms, Laplace transforms, and system analysis using transfer functions.', NULL, 'Signals and Systems', NULL, '1st Year', 'C', 'EE301'),
(106, 100, 'Teaches control theory including feedback, stability, time and frequency domain analysis, Bode plots, and PID controllers. Applications include automation and robotics.', NULL, 'Control Systems', NULL, '1st Year', 'C', 'EE302'),
(107, 100, 'Focuses on generation, transmission, and distribution of electric power. Topics include transformers, power flow analysis, fault analysis, and system protection.', NULL, 'Power Systems', NULL, '2nd Year', 'A', 'EE401'),
(108, 100, 'Covers microcontroller architecture (e.g., ARM or AVR), assembly language, interfacing with sensors, and real-time systems. Students build embedded systems using C and hardware kits (e.g., Arduino, STM32).', NULL, 'Microprocessors and Embedded Systems', NULL, '2nd Year', 'A', 'EE402'),
(109, 100, 'Explores solar, wind, hydro, and biomass energy generation. Covers system components, energy conversion, grid integration, and environmental impact.', NULL, 'Renewable Energy Systems', NULL, '2nd Year', 'B', 'EE403'),
(110, 100, 'Covers the theory and operation of electrical machines including transformers, synchronous machines, induction motors, and DC machines. Labs involve machine testing and performance evaluation.', NULL, 'Electrical Machines', NULL, '2nd Year', 'B', 'EE404'),
(111, 100, 'Focuses on the use of electronic devices in power conversion systems. Topics include rectifiers, inverters, choppers, and AC voltage controllers using SCRs, MOSFETs, and IGBTs.', NULL, 'Power Electronics', NULL, '2nd Year', 'C', 'EE405'),
(112, 100, 'Introduces the principles of measurement systems and instrumentation. Covers sensors, transducers, signal conditioning, and data acquisition.', NULL, 'Instrumentation and Measurement', NULL, '2nd Year', 'C', 'EE406'),
(113, 100, 'Teaches the planning and implementation of electrical wiring systems in residential and industrial buildings, including protection methods like circuit breakers, fuses, and grounding.', NULL, 'Electrical Installation and Protection', NULL, '3rd Year', 'A', 'EE407'),
(114, 100, 'Focuses on the generation, measurement, and testing of high voltages and currents. Topics include insulation coordination, breakdown mechanisms, and overvoltage protection.', NULL, 'High Voltage Engineering', NULL, '3rd Year', 'A', 'EE408'),
(115, 100, 'Explores how electrical energy is used in industrial and commercial applications. Topics include heating, lighting, traction, and energy efficiency.', NULL, 'Electrical Energy Utilization', NULL, '3rd Year', 'B', 'EE409'),
(116, 100, 'Introduces analog and digital communication techniques. Topics include AM/FM modulation, PCM, noise analysis, bandwidth, and transmission media.', NULL, 'Communication Systems', NULL, '3rd Year', 'B', 'EE410'),
(117, 100, 'Covers electronics and instrumentation used in healthcare, including ECG, EEG, pacemakers, and imaging technologies. Emphasizes safety and signal conditioning in biological systems.', NULL, 'Biomedical Instrumentation', NULL, '3rd Year', 'C', 'EE411'),
(118, 100, 'Focuses on automation technologies, robot kinematics, sensors, actuators, and control systems. Includes hands-on projects involving robotic arms and autonomous systems.', NULL, 'Robotics and Automation', NULL, '3rd Year', 'C', 'EE412'),
(201, 100, 'Introduces fundamental concepts of planning, organizing, leading, and controlling in business settings. Emphasizes managerial roles and decision-making processes.', NULL, 'Principles of Management', NULL, '1st Year', 'A', 'BA101'),
(202, 100, 'Covers the basics of financial statements, journal entries, ledgers, and accounting principles. Focuses on external reporting.', NULL, 'Financial Accounting', NULL, '1st Year', 'A', 'BA102'),
(203, 100, 'Explores the concepts of product, price, promotion, and place (4 Ps). Emphasizes market research and customer behavior.', NULL, 'Marketing Principles', NULL, '1st Year', 'A', 'BA103'),
(204, 100, 'Covers effective written, verbal, and non-verbal communication in professional environments. Includes business writing, reports, and presentations.', NULL, 'Business Communication', NULL, '1st Year', 'B', 'BA104'),
(205, 100, 'Focuses on consumer behavior, market demand/supply, pricing, and competition at the individual and firm level.', NULL, 'Microeconomics', NULL, '1st Year', 'B', 'BA105'),
(206, 100, 'Covers legal frameworks affecting business including contracts, torts, intellectual property, and employment law.', NULL, 'Business Law', NULL, '1st Year', 'B', 'BA106'),
(207, 100, 'Studies human behavior in organizations, including motivation, leadership, teamwork, and organizational culture.', NULL, 'Organizational Behavior', NULL, '1st Year', 'C', 'BA201'),
(208, 100, 'Examines national and global economies: GDP, inflation, unemployment, fiscal and monetary policy.', NULL, 'Macroeconomics', NULL, '1st Year', 'C', 'BA202'),
(209, 100, 'Covers recruitment, performance management, training, compensation, and labor relations.', NULL, 'Human Resource Management', NULL, '2nd Year', 'A', 'BA203'),
(210, 100, 'Focuses on costing systems, budgeting, and variance analysis to assist in managerial decision-making.', NULL, 'Cost Accounting', NULL, '2nd Year', 'A', 'BA204'),
(211, 100, 'Explores production planning, quality control, supply chain management, and process optimization.', NULL, 'Operations Management', NULL, '2nd Year', 'B', 'BA205'),
(212, 100, 'Discusses ethical dilemmas in business and the importance of CSR and sustainability.', NULL, 'Business Ethics and Corporate Social Responsibility', NULL, '2nd Year', 'B', 'BA206'),
(213, 100, 'Focuses on financial planning, capital structure, valuation, and investment analysis.', NULL, 'Financial Management', NULL, '2nd Year', 'C', 'BA301'),
(214, 100, 'Teaches how to develop and implement long-term strategies for competitive advantage.', NULL, 'Strategic Management', NULL, '2nd Year', 'C', 'BA302'),
(215, 100, 'Encourages creative thinking, opportunity recognition, business planning, and startup funding.', NULL, 'Entrepreneurship and Innovation', NULL, '3rd Year', 'A', 'BA303'),
(216, 100, 'Examines global trade, international markets, cultural dynamics, and global strategy.', NULL, 'International Business', NULL, '3rd Year', 'A', 'BA304'),
(217, 100, 'Explores how businesses use technology for decision-making, operations, and customer management.', NULL, 'Management Information Systems', NULL, '3rd Year', 'B', 'BA305'),
(218, 100, 'Covers project planning, scheduling, budgeting, and execution using PMI standards.', NULL, 'Project Management', NULL, '3rd Year', 'B', 'BA306');

-- --------------------------------------------------------

--
-- Table structure for table `course_programs`
--

CREATE TABLE `course_programs` (
  `course_id` bigint(20) NOT NULL,
  `program_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `id` bigint(20) NOT NULL,
  `enrollment_date` date DEFAULT NULL,
  `course_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `lecture_schedules`
--

CREATE TABLE `lecture_schedules` (
  `id` bigint(20) NOT NULL,
  `day_of_week` varchar(255) DEFAULT NULL,
  `end_time` time(6) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `start_time` time(6) DEFAULT NULL,
  `course_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lecture_schedules`
--

INSERT INTO `lecture_schedules` (`id`, `day_of_week`, `end_time`, `location`, `start_time`, `course_id`) VALUES
(22, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 1),
(23, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 2),
(24, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 3),
(25, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 2),
(26, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 3),
(27, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 4),
(28, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 1),
(29, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 5),
(30, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 5),
(31, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 6),
(32, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 6),
(33, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 4),
(34, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 2),
(35, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 7),
(36, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 4),
(37, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 7),
(38, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 2),
(39, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 7),
(40, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 4),
(41, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 8),
(42, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 8),
(43, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 9),
(44, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 9),
(45, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 9),
(46, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(47, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 5),
(48, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(49, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 5),
(50, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 8),
(51, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 8),
(52, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 6),
(53, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 16),
(54, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 6),
(55, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 17),
(56, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 6),
(57, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 6),
(58, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 101),
(59, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 102),
(60, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 103),
(61, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 102),
(62, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 103),
(63, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 104),
(64, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 101),
(65, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 105),
(66, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 105),
(67, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 106),
(68, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 106),
(69, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 104),
(70, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 107),
(71, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 108),
(72, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(73, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 108),
(74, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(75, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 110),
(76, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 107),
(77, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 111),
(78, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 111),
(79, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 112),
(80, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 112),
(81, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 110),
(82, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 113),
(83, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 114),
(84, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 115),
(85, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 114),
(86, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 115),
(87, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 116),
(88, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 113),
(89, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 117),
(90, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 117),
(91, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 118),
(92, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 118),
(93, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 116),
(94, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 201),
(95, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 202),
(96, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 201),
(97, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 202),
(98, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 205),
(99, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 204),
(100, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 205),
(101, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 204),
(102, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 203),
(103, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 203),
(104, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 2),
(105, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 7),
(106, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 4),
(107, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 7),
(108, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 2),
(109, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 7),
(110, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 4),
(111, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 8),
(112, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 8),
(113, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 9),
(114, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 9),
(115, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 9),
(116, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(117, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 5),
(118, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(119, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 5),
(120, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 8),
(121, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 8),
(122, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 6),
(123, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 16),
(124, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 6),
(125, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 17),
(126, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 6),
(127, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 6),
(128, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 13),
(129, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(130, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 15),
(131, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(132, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 15),
(133, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 16),
(134, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 13),
(135, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 14),
(136, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 13),
(137, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 16),
(138, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 16),
(139, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 16),
(140, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 17),
(141, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 18),
(142, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 17),
(143, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 18),
(144, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 17),
(145, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 18),
(146, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 17),
(147, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 18),
(148, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 17),
(149, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 18),
(150, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 18),
(151, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 18),
(152, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 12),
(153, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 11),
(154, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 12),
(155, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 11),
(156, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 12),
(157, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 11),
(158, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 12),
(159, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 11),
(160, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 12),
(161, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 11),
(162, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 12),
(163, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 12),
(164, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 107),
(165, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 108),
(166, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 107),
(167, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 108),
(168, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 107),
(169, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 108),
(170, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 107),
(171, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 108),
(172, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 107),
(173, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 108),
(174, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 108),
(175, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 108),
(176, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(177, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 110),
(178, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(179, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 110),
(180, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(181, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 110),
(182, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 109),
(183, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 110),
(184, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 109),
(185, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 110),
(186, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 110),
(187, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 110),
(188, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 111),
(189, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 112),
(190, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 111),
(191, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 112),
(192, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 111),
(193, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 112),
(194, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 111),
(195, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 112),
(196, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 111),
(197, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 112),
(198, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 112),
(199, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 112),
(200, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 209),
(201, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 210),
(202, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 209),
(203, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 210),
(204, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 211),
(205, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 212),
(206, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 211),
(207, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 212),
(208, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 213),
(209, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 213),
(210, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 17),
(211, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 18),
(212, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 17),
(213, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 18),
(214, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 17),
(215, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 18),
(216, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 17),
(217, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 18),
(218, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 17),
(219, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 18),
(220, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 18),
(221, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 18),
(222, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 12),
(223, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 11),
(224, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 12),
(225, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 11),
(226, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 12),
(227, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 11),
(228, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 12),
(229, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 11),
(230, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 12),
(231, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 11),
(232, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 12),
(233, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 12),
(234, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(235, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 110),
(236, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(237, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 110),
(238, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 109),
(239, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 110),
(240, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 109),
(241, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 110),
(242, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 109),
(243, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 110),
(244, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 110),
(245, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 110),
(246, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 111),
(247, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 112),
(248, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 111),
(249, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 112),
(250, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 111),
(251, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 112),
(252, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 111),
(253, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 112),
(254, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 111),
(255, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 112),
(256, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 112),
(257, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 112),
(258, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 211),
(259, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 212),
(260, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 211),
(261, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 212),
(262, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 213),
(263, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 214),
(264, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 213),
(265, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 214),
(266, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 213),
(267, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 213),
(268, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 214),
(269, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 213),
(270, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 214),
(271, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 213),
(272, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 214),
(273, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 213),
(274, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 214),
(275, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 213),
(276, 'Sunday', '14:30:00.000000', NULL, '13:00:00.000000', 214),
(277, 'Monday', '14:30:00.000000', NULL, '13:00:00.000000', 214),
(278, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 13),
(279, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(280, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 15),
(281, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 14),
(282, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 15),
(283, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 16),
(284, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 13),
(285, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 14),
(286, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 13),
(287, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 16),
(288, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 115),
(289, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 116),
(290, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 115),
(291, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 116),
(292, 'Thursday', '10:30:00.000000', NULL, '09:00:00.000000', 115),
(293, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 116),
(294, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 115),
(295, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 116),
(296, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 115),
(297, 'Thursday', '12:30:00.000000', NULL, '11:00:00.000000', 116),
(298, 'Sunday', '10:30:00.000000', NULL, '09:00:00.000000', 217),
(299, 'Monday', '10:30:00.000000', NULL, '09:00:00.000000', 218),
(300, 'Tuesday', '10:30:00.000000', NULL, '09:00:00.000000', 217),
(301, 'Wednesday', '10:30:00.000000', NULL, '09:00:00.000000', 218),
(302, 'Sunday', '12:30:00.000000', NULL, '11:00:00.000000', 218),
(303, 'Monday', '12:30:00.000000', NULL, '11:00:00.000000', 217),
(304, 'Tuesday', '12:30:00.000000', NULL, '11:00:00.000000', 218),
(305, 'Wednesday', '12:30:00.000000', NULL, '11:00:00.000000', 217);

-- --------------------------------------------------------

--
-- Table structure for table `programs`
--

CREATE TABLE `programs` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `programs`
--

INSERT INTO `programs` (`id`, `name`, `year`) VALUES
(1, 'Computer Science', '1st Year'),
(2, 'Electrical Engineering', '1st Year'),
(3, 'Business Administration', '1st Year'),
(4, 'Computer Science', '2nd Year'),
(5, 'Electrical Engineering', '2nd Year'),
(6, 'Business Administration', '2nd Year'),
(7, 'Computer Science', '3rd Year'),
(8, 'Electrical Engineering', '3rd Year'),
(9, 'Business Administration', '3rd Year');

-- --------------------------------------------------------

--
-- Table structure for table `program_courses`
--

CREATE TABLE `program_courses` (
  `program_id` bigint(20) NOT NULL,
  `course_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `program_courses`
--

INSERT INTO `program_courses` (`program_id`, `course_id`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(1, 5),
(1, 6),
(1, 7),
(1, 8),
(1, 9),
(1, 10),
(1, 11),
(1, 12),
(2, 101),
(2, 102),
(2, 103),
(2, 104),
(2, 105),
(2, 106),
(3, 201),
(3, 202),
(3, 203),
(3, 204),
(3, 205),
(3, 206),
(4, 13),
(4, 14),
(4, 15),
(4, 16),
(4, 17),
(4, 18),
(5, 107),
(5, 108),
(5, 109),
(5, 110),
(5, 111),
(5, 112),
(6, 209),
(6, 210),
(6, 211),
(6, 212),
(6, 213),
(6, 214),
(8, 113),
(8, 114),
(8, 115),
(8, 116),
(8, 117),
(8, 118),
(9, 215),
(9, 216),
(9, 217),
(9, 218);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `program_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_profiles`
--

CREATE TABLE `user_profiles` (
  `id` bigint(20) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `profile_image` longblob DEFAULT NULL,
  `student_id` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `image_content_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `course_programs`
--
ALTER TABLE `course_programs`
  ADD PRIMARY KEY (`course_id`,`program_id`),
  ADD KEY `FKnd0hy3d7tjj37fg5olcfafids` (`program_id`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKg1muiskd02x66lpy6fqcj6b9q` (`user_id`,`course_id`),
  ADD KEY `FKho8mcicp4196ebpltdn9wl6co` (`course_id`);

--
-- Indexes for table `lecture_schedules`
--
ALTER TABLE `lecture_schedules`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FKn5fa8fpl8uvtvnrv9w9stjqbj` (`course_id`);

--
-- Indexes for table `programs`
--
ALTER TABLE `programs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `program_courses`
--
ALTER TABLE `program_courses`
  ADD PRIMARY KEY (`program_id`,`course_id`),
  ADD KEY `FK9mu1ib0n0olkp2x9g9jmh04ba` (`course_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_r43af9ap4edm43mmtq01oddj6` (`username`),
  ADD UNIQUE KEY `unique_email` (`email`),
  ADD KEY `FKnygb5uvahfy3wrmd0xaj3hux2` (`program_id`);

--
-- Indexes for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_e5h89rk3ijvdmaiig4srogdc6` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1000;

--
-- AUTO_INCREMENT for table `enrollments`
--
ALTER TABLE `enrollments`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lecture_schedules`
--
ALTER TABLE `lecture_schedules`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=306;

--
-- AUTO_INCREMENT for table `programs`
--
ALTER TABLE `programs`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user_profiles`
--
ALTER TABLE `user_profiles`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `course_programs`
--
ALTER TABLE `course_programs`
  ADD CONSTRAINT `FKnd0hy3d7tjj37fg5olcfafids` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`),
  ADD CONSTRAINT `FKsv6x881vdjuqiinix5800p929` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `FK3hjx6rcnbmfw368sxigrpfpx0` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `FKho8mcicp4196ebpltdn9wl6co` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `lecture_schedules`
--
ALTER TABLE `lecture_schedules`
  ADD CONSTRAINT `FKn5fa8fpl8uvtvnrv9w9stjqbj` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `program_courses`
--
ALTER TABLE `program_courses`
  ADD CONSTRAINT `FK7l4efbrfhpoluthrk3toxp6bb` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`),
  ADD CONSTRAINT `FK9mu1ib0n0olkp2x9g9jmh04ba` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `FKnygb5uvahfy3wrmd0xaj3hux2` FOREIGN KEY (`program_id`) REFERENCES `programs` (`id`);

--
-- Constraints for table `user_profiles`
--
ALTER TABLE `user_profiles`
  ADD CONSTRAINT `FKjcad5nfve11khsnpwj1mv8frj` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
